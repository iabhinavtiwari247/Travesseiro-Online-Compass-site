import React, { useState, useEffect } from 'react';
import { Compass, AlertCircle } from 'lucide-react';

function App() {
  const [heading, setHeading] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!window.DeviceOrientationEvent) {
      setError("Your device doesn't support compass functionality");
      return;
    }

    const handleOrientation = (event: DeviceOrientationEvent) => {
      if (event.webkitCompassHeading) {
        // iOS devices
        setHeading(event.webkitCompassHeading);
      } else if (event.alpha) {
        // Android devices
        setHeading(360 - event.alpha);
      }
    };

    const requestPermission = async () => {
      try {
        // @ts-ignore: Typescript doesn't know about the requestPermission API
        if (DeviceOrientationEvent.requestPermission) {
          // @ts-ignore
          const permission = await DeviceOrientationEvent.requestPermission();
          if (permission === 'granted') {
            window.addEventListener('deviceorientation', handleOrientation, true);
          } else {
            setError('Permission to access compass was denied');
          }
        } else {
          window.addEventListener('deviceorientation', handleOrientation, true);
        }
      } catch (err) {
        setError('Error accessing compass: Please ensure you\'re using a mobile device');
      }
    };

    requestPermission();

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, []);

  const getCardinalDirection = (degree: number): string => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(degree / 45) % 8;
    return directions[index];
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 text-white flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {error ? (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-6 text-center">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-400" />
            <h2 className="text-xl font-semibold mb-2">Device Error</h2>
            <p className="text-slate-300">{error}</p>
          </div>
        ) : (
          <div className="text-center">
            <div className="relative inline-block">
              <div 
                className="w-64 h-64 rounded-full border-4 border-blue-500/30 relative"
                style={{ 
                  transform: `rotate(${heading !== null ? heading : 0}deg)`,
                  transition: 'transform 0.3s ease-out'
                }}
              >
                <Compass className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 text-blue-400" />
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-4 h-4 bg-red-500 rounded-full" />
                </div>
              </div>
            </div>
            
            <div className="mt-8 bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10">
              <h2 className="text-2xl font-semibold mb-2">
                {heading !== null ? `${Math.round(heading)}°` : '--°'}
              </h2>
              <p className="text-lg text-blue-400">
                {heading !== null ? getCardinalDirection(heading) : '--'}
              </p>
              <p className="text-sm text-slate-400 mt-2">
                Point your device in any direction to get started
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;